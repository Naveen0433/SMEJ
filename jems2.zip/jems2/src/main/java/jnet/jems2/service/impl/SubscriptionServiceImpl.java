//package jnet.jems2.service.impl;
//
////import java.io.File;
//import java.io.IOException;
////import java.io.StringReader;
//import java.nio.file.Files;
//import java.nio.file.Path;
////import java.util.ArrayList;
//import java.util.HashSet;
////import java.util.LinkedHashMap;
//import java.util.List;
////import java.util.Map;
//import java.util.Objects;
//import java.util.Optional;
//import java.util.Set;
//import java.util.stream.Collectors;
//
//
//import org.bson.BsonBinarySubType;
////import org.bson.Document;
//import org.bson.types.Binary;
//import org.json.JSONException;
//import org.json.JSONObject;
//import org.json.XML;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.FindAndModifyOptions;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Criteria;
//import org.springframework.data.mongodb.core.query.Query;
//import org.springframework.data.mongodb.core.query.Update;
//import org.springframework.stereotype.Service;
//import org.springframework.web.multipart.MultipartFile;
//
//import jnet.jems2.model.Subscription;
//import jnet.jems2.model.SubscriptionSequence;
//import jnet.jems2.repository.SubscriptionRepository;
//import jnet.jems2.service.SubscriptionService;
//
//import java.io.StringReader;
//import java.io.StringWriter;
//
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.OutputKeys;
//import javax.xml.transform.Result;
//import javax.xml.transform.Source;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerException;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//
//import org.w3c.dom.Document;
//import org.xml.sax.InputSource;
//
//@Service
//public class SubscriptionServiceImpl implements SubscriptionService{
//
//	@Autowired
//	private SubscriptionRepository subscriptionRepository;
//
//	@Autowired
//	private MongoTemplate mongoTemplate;
//
//	@Override
//	public Subscription save(Subscription subscription) {
//
//		subscription.setSubscriptionId(generateSequence(Subscription.SEQUENCE_NAME));
////		for(String s:subscription.getObligationFilterXmlText()) {
////			this.stringToXml(s);
////		}
//		return subscriptionRepository.insert(subscription);
//	}
//
//	@Override
//	public Subscription update(Subscription subscription) {
//		return subscriptionRepository.save(subscription);
//	}
//
//	@Override
//	public void delete(Long subscriptionId) {
//		subscriptionRepository.delete(subscriptionRepository.findById(subscriptionId).get());
//	}
//
//	@Override
//	public List<Subscription> getAll() {
//		List<Subscription> list= subscriptionRepository.findAll();
//		/*for(Subscription subscription : list) {
//
//		}*/
//		return list;
//	}
//
//
//	@SuppressWarnings("unused")
//	private long generateSequence(String seqName) {
//		Query query = new Query();
//		query.addCriteria(Criteria.where("_id").is(seqName));
//		SubscriptionSequence counter = mongoTemplate.findAndModify(query, new Update().inc("sequence", 1),
//				new FindAndModifyOptions().returnNew(true).upsert(true), SubscriptionSequence.class);
//		return !Objects.isNull(counter) ? counter.getSequence() : 1;
//	}
//
//
////
////	@Override
////	public void uploadFile(MultipartFile file) {
////
////	}
////
////
////	public void stringToXml(String xmlString) {
////		//String xmlString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"></soap:Envelope>";
////
////        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
////
////        DocumentBuilder builder;
////        try
////        {
////            builder = factory.newDocumentBuilder();
////
////            // Use String reader
////            Document document = builder.parse( new InputSource(
////                    new StringReader( xmlString ) ) );
////
////            TransformerFactory tranFactory = TransformerFactory.newInstance();
////            Transformer aTransformer = tranFactory.newTransformer();
////            Source src = new DOMSource( document );
////            Result dest = new StreamResult( new File( "xmlFileName.xml" ) );
////            aTransformer.transform( src, dest );
////	}catch (Exception e) {
////        e.printStackTrace();
////    }
////
////}
////
////	@Override
////	public List<Map<String,String>> allObligationFilters() {
////		List filterList=new ArrayList();
////		Query query=new Query();
////		query.fields().include("obligationFilter");
////		List<Subscription> list=this.mongoTemplate.find(query, Subscription.class);
////		for(Subscription s:list) {
////			List obgFilList=s.getObligationFilter();
////			if(obgFilList!=null) {
////			for(Object obj:obgFilList) {
////				LinkedHashMap<String, String> ObligationFilter=(LinkedHashMap<String, String>)obj;
////				filterList.add(ObligationFilter);
////			}
////			}
////		}
////		return filterList;
////	}
//
//
//}
package jnet.jems2.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import jnet.jems2.model.Subscription;
import jnet.jems2.model.SubscriptionSequence;
import jnet.jems2.repository. SubscriptionRepository;
import jnet.jems2.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService{

	@Autowired
	private SubscriptionRepository subscriptionRepository;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Subscription save(Subscription subscription) {
		subscription.setSubscriptionId(generateSequence(Subscription.SEQUENCE_NAME));
		return subscriptionRepository.insert(subscription);
	}

	@Override
	public Subscription update(Subscription subscription) {
		return subscriptionRepository.save(subscription);
	}

	@Override
	public void delete(Long subscriptionId) {
		subscriptionRepository.delete(subscriptionRepository.findById(subscriptionId).get());
	}

	@Override
	public List<Subscription> getAll() {
		List<Subscription> list= subscriptionRepository.findAll();
		return list;
	}


	private long generateSequence(String seqName) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(seqName));
		SubscriptionSequence counter = mongoTemplate.findAndModify(query, new Update().inc("sequence", 1),
				new FindAndModifyOptions().returnNew(true).upsert(true), SubscriptionSequence.class);
		return !Objects.isNull(counter) ? counter.getSequence() : 1;
	}






}
