package jnet.jems2.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;
import jnet.jems2.model.Subscription;

public interface SubscriptionService {
	public Subscription save(Subscription subscription);
	public Subscription update(Subscription subscription);
	public void delete(Long subscriptionId);
	public List<Subscription> getAll();
//	public void uploadFile(MultipartFile file);
//	public List<Map<String,String>> allObligationFilters();
}
